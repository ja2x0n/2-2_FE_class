import { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { DiaryStateContext } from "../App";

const useDiary = (id) => {
    const data = useContext(DiaryStateContext);
    const [diary, setDiary] = useState();
    const navigate = useNavigate();

    useEffect(() => {
        const matchDiary = data.find((it) => String(it.id) === String(id));

        if (matchDiary) {
            // eslint-disable-next-line react-hooks/set-state-in-effect
            setDiary(matchDiary);
        } else {
            alert("일기가 존재하지 않습니다.");
            navigate("/", { replace: true });
        }
    }, [id, data, navigate]);

    return diary;
};

export default useDiary;
