import "./Button.css";

const Button = ({ text, type = "default", onClick }) => {
    const btnType = ["positive", "negative"].includes(type) ? type : "default";
    return (
        <button className={`Button Button_${btnType}`} onClick={onClick}>
            {text}
        </button>
    );
};
export default Button;
